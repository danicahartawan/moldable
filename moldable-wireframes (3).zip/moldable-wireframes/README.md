# Moldable wireframes (grandkid side, 5.73 in display)

Both 640 × 640 screens as they stand on the canvas now.

- `Home.dc.html`: 07 Grandkid home view
- `Explore.dc.html`: 08 Explore recipes
- `canvas.json`: board positions, titles and notes
- `assets/lelawar-photo.png`: the dish photo used on both screens

## Home view
- Recipe card: title with a round toggle, dish photo, a one-line overview and Steps / Serves / Spice. The toggle switches to an 8-step list that scrolls under a soft blur.
- Top right: rolls between cooking time and tools, on tap or by itself every few seconds.
- Bottom right: all 11 ingredients in two columns.
- Bottom left: Adjust opens Modify (Serves 2, Less spicy, Chicken) and Tidy amounts.
- Voice: on the device it starts when you talk. In the file it plays once 3 seconds after load; tap the top-left corner to replay.

## Explore recipes
- Each spinning globe of magnet cards is one cookbook. Swipe left or right (or two-finger swipe on a trackpad) to switch books. The dots under the title show which one you're on.
- Tap the globe and the cards flatten into a scrolling grid with frosted top and bottom. Tap a card to open it big.
- Press the notch on the left edge (the hardware notch) to slide in Search, Modify and Tidy.
- Cookbooks and recipes other than Lelawar Bali are placeholders.

## Not included
- ABC Arizona fonts: the canvas uses trial files that can't be redistributed. The screens fall back to system fonts until you add licensed `@font-face` rules.
- The canvas runtime (`support.js`), so opening a file in a browser shows the raw template. Treat these as source for building the real screens. For images, download from the canvas.
- Photo rights: the dish photo was supplied as a reference; check you can use it before sharing.
