# Moldable design system

## What's inside

| Folder | What it is |
| --- | --- |
| `motion-system/index.html` | The live motion and interaction page. Open it in a browser. It loads React and Archivo from public CDNs, so it needs an internet connection. |
| `design-system/README.md` | The brand book: voice, colour, type, space, motion, iconography. |
| `design-system/tokens.json` | Every token (colour per theme, type, spacing, radius, shadow, duration, easing). The source of truth. |
| `design-system/tokens.css` | The same tokens as CSS custom properties, plus a class per type style. Switch themes with `data-theme="light"` or `data-theme="dark"` on any element. |
| `design-system/components/` | `bundle.js` (React 18 components on `window.Moldable`), `bundle.css`, `index.d.ts` (props), and a `README.md` and `preview.html` per component. |
| `brand/` | The logo: the original artwork and a transparent version for tinting with CSS masks. |
| `fonts/` | Archivo (variable: width and weight, roman and italic) under the SIL Open Font License. |

## Using the components

Load these in order: `tokens.css`, `components/bundle.css`, React 18 and ReactDOM 18 (UMD), then `components/bundle.js`. After that, `window.Moldable.Button` and the other components are ready.

The `preview.html` files expect to be loaded inside the design-system viewer, where those files are already preloaded. To open one directly, add the same four includes at the top.

## Fonts

The ABC Arizona trial fonts aren't included, because the trial licence doesn't allow redistribution. Arizona appears only in the logo artwork.
