Moldable is a cutting board that walks you through a family recipe one step at a time, and an app that saves those recipes in the cook's own words. The design should feel like a well-kept kitchen: warm, plain and calm, with blue-rimmed enamelware and a recipe card in grandma's hand. It should not feel like a gadget. Everything below exists to keep a cook's eyes on the food and a grandmother's voice intact.

## Two surfaces

| Surface | Theme | Reading distance | Rules |
| --- | --- | --- | --- |
| Phone and tablet app (saving, browsing, sharing) | **Kitchen (light)** by default, Board (dark) when the OS is dark | Hand-held | Body text `body` (18px). One `primary` button per screen. |
| The board (cooking) | Always **Board (dark)** | Standing, arm's length, wet hands | One instruction at a time in `BoardStep`. Text no smaller than `board-cue` (28px), except the eyebrow and timer label. Tap targets 60px (`Button size="lg"`). |

Older cooks and their grandchildren both use the app. Never set anything a cook needs to act on below 18px, and never put an instruction in `caption`.

## Voice and content

- **Her words stay hers.** Show the original cook's phrasing verbatim, in its original language and spelling, wherever she is quoted: `RecipeCard` `quote`, `BoardStep` `quote`. Set her words in `quote` (Archivo Italic) on `heirloom-soft`, and always say where they came from ("Oma Lien, voice note 2019").
- **Moldable's own voice is plain and kind.** Use short sentences, imperative verbs and sentence case. Write "Fry the spice paste over low heat", not "Let's get frying! 🔥".
- **Give cues, not just times.** Every timed step also says what to look, smell or listen for: "until the oil starts to separate".
- **Address the person as "you" and the cook by name.** "Hold the card flat." "From Oma Lien." Don't say "the user" or "the author".
- **Keep the cook's units.** If her card says cups, show cups with kitchen fractions (½, ¾); don't convert.
- Use no emoji. Use no exclamation marks except in her own quotes.
- Name things the way a family would: *family book*, not library; *card*, not document; *her voice note*, not audio file.

## Colour

The ground is `flour`, with `flour-raised` for cards and `flour-sunken` for wells and tracks. Text is `ink`, with `ink-muted` for metadata. Hairlines are `line`. Borders on controls are `line-strong`.

- **`enamel`** is the only action colour: primary buttons, links, the current step and focus. Put `on-enamel` on top of it.
- **`yolk`** is the glow. It means "this is happening now": the progress stroke, the running timer, the lit timeline segments and the scan corners. At most one glowing thing at a time. Never use it as text; use `yolk-ink` on `yolk-soft` for in-progress and warning labels.
- **`heirloom`** belongs to the family: Heirloom chips and the cook's quoted words. Never use it for an action.
- `basil` means success and `chili` means failure, each paired with its `-soft` ground and always with an icon.
- `card-rule` and `card-margin` draw only the recipe-card motif. They are decoration, never text.

### Thermal scale

Four ironbow tones sampled from a thermal-camera frame, coldest to hottest: `thermal-violet`, `thermal-magenta`, `thermal-ember`, `thermal-flare`. They are Moldable's sign of heat and are the same in both themes.

- Use them stepped, one flat tone per pixel. Never blend them into a gradient, and never add a fifth tone.
- Use them only for moments about heat or transition: the `ThermalWave` reveal on menus and sheets, and heat readouts on the board. They don't replace `yolk` (the live glow), `enamel` (actions) or any status colour.
- Never set text in a thermal tone or on a thermal fill. They're fills under motion, and the content they reveal carries the meaning.
- Always show them together, cold to hot. `thermal-flare` alone on `flour` is too faint to read.

Every text pair above passes 4.5:1 in both themes, and `line-strong`, `yolk` and `focus` pass 3:1 against the surfaces they sit on.

## Type

Moldable uses one family, **Archivo**, for everything. The logo is the only exception: it's fixed artwork in ABC Arizona Flare and is never re-typeset.

- **Display** (`display-xl`, `display-l`, `display-m`) is Archivo Medium, tightly tracked, for recipe names and section openers. Use at most one `display-xl` per screen.
- **Her words** (`quote`) are Archivo *Italic*. Italic is reserved for the original cook's own words, so it always means "she said this". Don't use italic for emphasis anywhere else.
- **Interface** (`title`, `body-l`, `body`, `label`, `caption`, `eyebrow`) and **Board** (`board-step`, `board-cue`, `board-timer`) are Archivo at the normal width. Narrower widths (the `wdth` axis, 62–125) are allowed only on the board, to fit a long instruction on one line.
- Use tabular figures for every quantity and timer.
- Write in sentence case. Only `eyebrow` is uppercase, tracked at 0.08em.

Archivo loads from Google Fonts (`components/bundle.css`) under the SIL Open Font License.

## Space, shape, depth

- Spacing runs `space-1` (4px) to `space-9` (96px). Cards take `space-4` padding on phones and `space-5` everywhere else. On the board, keep content `space-7` (48px) away from the physical edge.
- Radii: `radius-pill` for chips, the progress pill and md buttons; `radius-md` for fields, the stepper and lg buttons; `radius-lg` for cards and sheets. `radius-sm` is for small markers only.
- Show depth with a wide, soft shadow plus a 1px ring: `shadow-1` at rest and `shadow-2` for sheets and menus. Don't add borders to cards. `glow` belongs to the one live element.

## Motion

Motion shows a state change. It is never decoration.

| Moment | Pattern | Tokens |
| --- | --- | --- |
| Uploading or transcribing | A glowing stroke travels round the outline of `ProgressPill` | `yolk`, `glow`, `dur-settle` |
| A button's action | The label swaps in place: dot spinner, then a drawn check (`Button` `status`) | `dur-base`, `ease-out` |
| Servings change | Digits scramble, then settle (`Quantity`) | `dur-settle` |
| Moving through a recipe | The current stage lights up and the others fade (`StepTimeline`) | `ink-faint`, `yolk`, `dur-settle` |
| Timer running | The arc drains with a glow; a paused timer loses the glow | `yolk`, `glow` |
| Menus and sheets opening | A heat wave of 10px pixels spreads from the trigger, flare at the front, cooling to violet, then clears (`ThermalWave`) | `thermal-*`, 560ms |

Respect `prefers-reduced-motion`: the scramble, spinner, label rise and thermal wave are switched off, and the progress stroke slows down.

## Iconography

Use the `Icon` component: a 20px grid, 1.6 stroke, round caps, `currentColor`. Icons always sit next to a word unless they have a `label`. The kitchen glyphs (`knife`, `pot`, `flame`) mark cooking actions only. The logo is a black portrait block with a cut-out dot, next to the Moldable wordmark in ABC Arizona Flare. Use the supplied artwork and never retype the wordmark.

## Components

`Button`, `Chip`, `Icon`, `ProgressPill`, `StepTimeline`, `Quantity`, `ServingStepper`, `Field`, `RecipeCard`, `BoardStep`, `ThermalWave`. Each one has a guideline with its props. The **Screens** group shows them together: the phone capture flow (scan, then transcribe, then save) and Cook mode on the board.
