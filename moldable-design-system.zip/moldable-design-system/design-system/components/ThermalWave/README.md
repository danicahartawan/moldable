# ThermalWave

A heat wave of stepped thermal pixels that burns away to reveal a menu or sheet, or covers it again as it closes.

**Props:** `mode` `"in" | "out"` (default in) · `cell` pixel size in px (default 10) · `duration` ms (default 560) · `originX`, `originY` where the heat starts, 0–1 across the container (default 0, 0: top-left, next to a trigger above it) · `onDone`.

- Put it as the **last child** of the container it covers. The container needs `position: relative` and `overflow: hidden`.
- Remount it with a new `key` to play again. Use `mode="out"` on close and unmount the container after `duration`.
- It paints only the four thermal tokens, in steps: flare at the front, cooling through ember and magenta to violet. Don't pass other colours.
- Use it for menus and sheets that open from a control, and nowhere else. One wave on screen at a time.
- It is decorative and hidden from screen readers. With reduced motion on it doesn't run and the content appears straight away.
