# StepTimeline

The stages of a recipe: done stages show a check, the current one is lit with a segmented `yolk` bar, and upcoming ones recede to `ink-faint`.

**Props:** `steps` `[{ label, note? }]` · `active` the index of the current stage · `progress` 0–1 through the current stage · `label` (accessible name).

- Three to six stages. These group the steps (Prep, Fry, Simmer); they don't list every instruction.
- `note` is one short line in the cook's terms.
- Advance `active` when the board confirms a stage is done. Never skip ahead on a timer alone.
- Upcoming stages use `ink-faint` on purpose: they are context, not instructions.
