# ServingStepper

Minus and plus buttons around a servings count. It scales every `Quantity` on the screen.

**Props:** `value` · `onChange(n)` · `min` (default 1) · `max` (default 24).

- The buttons are 44px targets inside a `flour-sunken` well. Don't make them smaller.
- Put it above the ingredient list, never inside it.
