# Button

Triggers one action; the label says exactly what happens, and the button itself shows the action working and finishing.

**Props:** `variant` `"primary" | "secondary" | "quiet"` (default primary) · `size` `"md" | "lg"` · `icon` an `Icon` name · `status` `"idle" | "working" | "done"` · `workingLabel`, `doneLabel` · plus any native button prop (`onClick`, `disabled`, `type`).

- One `primary` per screen. Use `size="lg"` for the main action on the board and in Cook mode, where hands may be wet or floury (60px tall).
- The consumer owns `status`. Set `working` the moment the action starts, `done` when it lands, and return to `idle` after about 1.8s. Don't open a separate spinner or toast for the same action.
- Write labels as verbs in sentence case: "Save recipe", "Scan a card". `doneLabel` says what happened: "Saved to family book".
- A `done` primary turns `basil`; secondary and quiet just swap their icon for a drawn check.
- `quiet` is for the secondary path next to a primary ("Record her telling it"), never on its own as the only action.
