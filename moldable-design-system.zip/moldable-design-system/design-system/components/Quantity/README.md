# Quantity

An ingredient amount that scrambles its digits for about 420ms when it changes, then settles, so the cook notices that it moved.

**Props:** `value` a number · `unit` a string. With `cup`, `cups`, `tsp` or `tbsp` the number is shown as a kitchen fraction (½, ⅓, ¾); grams and millilitres are rounded sensibly.

- Use it for every amount that responds to `ServingStepper`. Static amounts can be plain text.
- Keep units in the cook's own system. If the original card says "cups", show cups and don't convert.
- The scramble is skipped when the person has reduced motion turned on.
