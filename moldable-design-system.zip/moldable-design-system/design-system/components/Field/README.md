# Field

A labelled text input or textarea with an optional hint or error underneath.

**Props:** `label` (required) · `value`/`onChange` or `defaultValue` · `placeholder` · `hint` · `error` (replaces the hint and turns the border `chili`) · `multiline`, `rows` · `trailing` (a node such as a quiet icon button) · `id`.

- Phrase labels as the question a grandchild would ask: "Whose recipe is this?"
- Errors say what to type instead: "Use a year or a decade, like 1974 or 1970s."
- Input text is 18px. Don't shrink it.
