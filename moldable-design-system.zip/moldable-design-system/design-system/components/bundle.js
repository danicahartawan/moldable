/* @ds-bundle: {"format":4,"namespace":"Moldable","components":[{"name":"Button"},{"name":"Chip"},{"name":"Icon"},{"name":"ProgressPill"},{"name":"StepTimeline"},{"name":"Quantity"},{"name":"ServingStepper"},{"name":"Field"},{"name":"RecipeCard"},{"name":"BoardStep"},{"name":"ThermalWave"}]} */
(function () {
  var R = window.React, h = R.createElement;
  var useState = R.useState, useEffect = R.useEffect, useRef = R.useRef, useLayoutEffect = R.useLayoutEffect;
  function cx() { return Array.prototype.filter.call(arguments, Boolean).join(' '); }
  function reduced() {
    try { return window.matchMedia('(prefers-reduced-motion: reduce)').matches; } catch (e) { return false; }
  }

  /* ---------- Icon: 20px grid, 1.6 stroke, round caps ---------- */
  var CIRCLE = 'M10 3a7 7 0 1 1 0 14a7 7 0 1 1 0-14z';
  var PATHS = {
    check: ['M5 10.5l3.2 3.2L15 6.8'],
    'check-circle': [CIRCLE, 'M7 10.2l2.1 2.1L13.2 8'],
    x: ['M6 6l8 8M14 6l-8 8'],
    'x-circle': [CIRCLE, 'M7.8 7.8l4.4 4.4M12.2 7.8l-4.4 4.4'],
    pencil: ['M4 16l.9-3.6L12.6 4.7a1.6 1.6 0 0 1 2.3 0l.4.4a1.6 1.6 0 0 1 0 2.3L7.6 15.1z', 'M11.4 5.9l2.7 2.7'],
    clock: [CIRCLE, 'M10 6.5V10l2.4 1.5'],
    flame: ['M10 17c-2.9 0-5-2-5-4.7 0-2.7 2.1-4 2.6-6.6 1 1.1 1.5 2.1 1.5 3.4C10.3 7.4 11.3 5.2 10.8 3c2.7 1.7 4.2 4.6 4.2 7.4C15 14.6 13 17 10 17z'],
    alert: ['M7 3.5h6l3.5 6.5-3.5 6.5H7L3.5 10z', 'M10 7v3.4', 'M10 13.2v.1'],
    scan: ['M3.5 7V3.5H7M13 3.5h3.5V7M16.5 13v3.5H13M7 16.5H3.5V13', 'M3.5 10h13'],
    book: ['M15.5 13.5H6a1.5 1.5 0 0 0 0 3h9.5v-13H6A1.5 1.5 0 0 0 4.5 5v10'],
    eye: ['M2.5 10s2.8-5 7.5-5 7.5 5 7.5 5-2.8 5-7.5 5-7.5-5-7.5-5z', 'M10 7.8a2.2 2.2 0 1 1 0 4.4a2.2 2.2 0 1 1 0-4.4z'],
    knife: ['M3.5 16.5L14.6 5.4a2.8 2.8 0 0 1 0 4L9.5 14.5z', 'M11.5 11.5l1.3 1.3'],
    mic: ['M10 3a2.5 2.5 0 0 1 2.5 2.5v4a2.5 2.5 0 0 1-5 0v-4A2.5 2.5 0 0 1 10 3z', 'M5.5 9.5a4.5 4.5 0 0 0 9 0M10 14v3'],
    plus: ['M10 4.5v11M4.5 10h11'],
    minus: ['M4.5 10h11'],
    share: ['M10 3v9.5M6.5 6.5L10 3l3.5 3.5', 'M4.5 11v5h11v-5'],
    heart: ['M10 16s-6-3.6-6-8a3.3 3.3 0 0 1 6-1.9A3.3 3.3 0 0 1 16 8c0 4.4-6 8-6 8z'],
    pot: ['M3.5 8.5h13M5 8.5v6a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2v-6', 'M2.5 8.5h1M16.5 8.5h1M8 6l.6-1.5M11.4 6l.6-1.5']
  };
  function Icon(p) {
    var size = p.size || 20, d = PATHS[p.name] || PATHS.check;
    return h('svg', {
      className: cx('md-icon', p.className), width: size, height: size, viewBox: '0 0 20 20', fill: 'none',
      stroke: 'currentColor', strokeWidth: p.strokeWidth || 1.6, strokeLinecap: 'round', strokeLinejoin: 'round',
      'aria-hidden': p.label ? undefined : 'true', role: p.label ? 'img' : undefined, 'aria-label': p.label
    }, d.map(function (x, i) { return h('path', { key: i, d: x }); }));
  }
  Icon.names = Object.keys(PATHS);

  /* ---------- Dot spinner (3x3 grid, from the label-picker "Creating" state) ---------- */
  function DotSpinner() {
    var dots = [];
    for (var i = 0; i < 9; i++) {
      dots.push(h('circle', { key: i, cx: 4 + (i % 3) * 6, cy: 4 + Math.floor(i / 3) * 6, r: 1.4, style: { animationDelay: ((i % 3 + Math.floor(i / 3)) * 90) + 'ms' } }));
    }
    return h('svg', { className: 'md-dots', width: 20, height: 20, viewBox: '0 0 20 20', 'aria-hidden': 'true' }, dots);
  }

  /* ---------- Button ---------- */
  function Button(p) {
    var variant = p.variant || 'primary', size = p.size || 'md', status = p.status || 'idle';
    var label = status === 'working' ? (p.workingLabel || p.children) : status === 'done' ? (p.doneLabel || p.children) : p.children;
    var lead = status === 'working' ? h(DotSpinner) : status === 'done' ? h(Icon, { name: 'check', className: 'md-draw' }) : (p.icon ? h(Icon, { name: p.icon }) : null);
    var rest = {};
    for (var k in p) if (['variant', 'size', 'status', 'icon', 'workingLabel', 'doneLabel', 'children', 'className'].indexOf(k) < 0) rest[k] = p[k];
    rest.className = cx('md-btn', 'md-btn-' + variant, 'md-btn-' + size, status !== 'idle' && 'md-btn-' + status, p.className);
    rest['aria-busy'] = status === 'working' ? 'true' : undefined;
    if (!rest.type) rest.type = 'button';
    return h('button', rest, lead, h('span', { className: 'md-btn-label', key: status }, label));
  }

  /* ---------- Chip ---------- */
  var CHIP_ICON = { neutral: 'pencil', enamel: 'share', basil: 'check-circle', yolk: 'alert', chili: 'x-circle', heirloom: 'book' };
  function Chip(p) {
    var tone = p.tone || 'neutral';
    var icon = p.icon === false ? null : h(Icon, { name: p.icon || CHIP_ICON[tone], size: 18 });
    return h('span', { className: cx('md-chip', 'md-chip-' + tone, p.className) }, icon, h('span', null, p.children));
  }

  /* ---------- ProgressPill: a glowing stroke travels round the outline ---------- */
  function ProgressPill(p) {
    var ref = useRef(null), st = useState({ w: 0, h: 0 }), box = st[0], setBox = st[1];
    var indeterminate = p.value == null;
    var v = indeterminate ? 0.28 : Math.max(0, Math.min(1, p.value));
    useLayoutEffect(function () {
      var el = ref.current; if (!el) return;
      function m() { setBox({ w: el.offsetWidth, h: el.offsetHeight }); }
      m();
      var ro = typeof ResizeObserver !== 'undefined' ? new ResizeObserver(m) : null;
      if (ro) ro.observe(el);
      return function () { if (ro) ro.disconnect(); };
    }, []);
    var gap = 10, sw = 3, W = box.w + gap * 2, H = box.h + gap * 2;
    var r = H / 2 - sw / 2;
    var svg = box.w ? h('svg', { className: 'md-pp-ring', width: W, height: H, viewBox: '0 0 ' + W + ' ' + H, 'aria-hidden': 'true' },
      h('rect', { className: 'md-pp-track', x: sw / 2, y: sw / 2, width: W - sw, height: H - sw, rx: r, pathLength: 100 }),
      h('rect', {
        className: cx('md-pp-stroke', indeterminate && 'md-pp-loop'), x: sw / 2, y: sw / 2, width: W - sw, height: H - sw, rx: r, pathLength: 100,
        strokeDasharray: (v * 100) + ' ' + (100 - v * 100 + 0.001), strokeDashoffset: indeterminate ? undefined : 0
      })) : null;
    var pct = indeterminate ? undefined : Math.round(v * 100);
    return h('div', {
      className: cx('md-pp', p.className), role: 'progressbar', 'aria-label': p.label,
      'aria-valuemin': indeterminate ? undefined : 0, 'aria-valuemax': indeterminate ? undefined : 100, 'aria-valuenow': pct
    }, svg, h('div', { className: 'md-pp-body', ref: ref }, p.icon ? h(Icon, { name: p.icon }) : null,
      h('span', { className: 'md-pp-label' }, p.label), pct != null && p.showValue !== false ? h('span', { className: 'md-pp-val' }, pct + '%') : null));
  }

  /* ---------- StepTimeline: active step lit, the rest recede ---------- */
  function StepTimeline(p) {
    var steps = p.steps || [], active = p.active || 0, prog = p.progress == null ? 0 : p.progress;
    var segs = 12, lit = Math.round(prog * segs);
    return h('ol', { className: cx('md-tl', p.className), 'aria-label': p.label || 'Recipe stages' }, steps.map(function (s, i) {
      var state = i < active ? 'done' : i === active ? 'now' : 'next';
      var bar = null;
      if (state === 'now') {
        var cells = [];
        for (var c = 0; c < segs; c++) cells.push(h('i', { key: c, className: c < lit ? 'on' : '' }));
        bar = h('div', { className: 'md-tl-bar', 'aria-hidden': 'true' }, cells);
      }
      return h('li', { key: i, className: 'md-tl-step md-tl-' + state, 'aria-current': state === 'now' ? 'step' : undefined },
        h('div', { className: 'md-tl-head' },
          h('span', { className: 'md-tl-mark' }, state === 'done' ? h(Icon, { name: 'check', size: 16 }) : String(i + 1)),
          h('span', { className: 'md-tl-label' }, s.label)),
        s.note ? h('p', { className: 'md-tl-note' }, s.note) : null, bar);
    }));
  }

  /* ---------- Quantity: digits scramble, then settle (from the card-number reveal) ---------- */
  var FR = [[0, ''], [0.125, '⅛'], [0.25, '¼'], [1 / 3, '⅓'], [0.5, '½'], [2 / 3, '⅔'], [0.75, '¾'], [1, '']];
  var FRACTION_UNITS = ['cup', 'cups', 'tsp', 'tbsp'];
  function fmt(n, unit) {
    if (FRACTION_UNITS.indexOf(unit) >= 0) {
      var whole = Math.floor(n), rem = n - whole, best = FR[0];
      FR.forEach(function (f) { if (Math.abs(f[0] - rem) < Math.abs(best[0] - rem)) best = f; });
      if (best[0] === 1) { whole += 1; best = FR[0]; }
      return (whole ? String(whole) : '') + best[1] || '0';
    }
    if (n >= 100) return String(Math.round(n / 5) * 5);
    if (n >= 10) return String(Math.round(n));
    return String(Math.round(n * 10) / 10);
  }
  function scramble(s) { return s.replace(/[0-9]/g, function () { return String(Math.floor(Math.random() * 10)); }); }
  function Quantity(p) {
    var target = fmt(p.value, p.unit);
    var st = useState(target), shown = st[0], setShown = st[1];
    var first = useRef(true);
    useEffect(function () {
      if (first.current || reduced()) { first.current = false; setShown(target); return; }
      var t0 = Date.now(), id = setInterval(function () {
        if (Date.now() - t0 > 420) { clearInterval(id); setShown(target); } else setShown(scramble(target));
      }, 45);
      return function () { clearInterval(id); };
    }, [target]);
    return h('span', { className: cx('md-qty', shown !== target && 'md-qty-busy', p.className), 'aria-live': 'polite' },
      h('span', { className: 'md-qty-n' }, shown), p.unit ? h('span', { className: 'md-qty-u' }, ' ' + p.unit) : null);
  }

  /* ---------- ServingStepper ---------- */
  function ServingStepper(p) {
    var min = p.min || 1, max = p.max || 24, v = p.value;
    function set(n) { if (p.onChange) p.onChange(Math.max(min, Math.min(max, n))); }
    return h('div', { className: cx('md-step', p.className), role: 'group', 'aria-label': 'Servings' },
      h('button', { type: 'button', className: 'md-step-btn', onClick: function () { set(v - 1); }, disabled: v <= min, 'aria-label': 'Fewer servings' }, h(Icon, { name: 'minus' })),
      h('span', { className: 'md-step-val' }, h('b', null, v), ' ', v === 1 ? 'serving' : 'servings'),
      h('button', { type: 'button', className: 'md-step-btn', onClick: function () { set(v + 1); }, disabled: v >= max, 'aria-label': 'More servings' }, h(Icon, { name: 'plus' })));
  }

  /* ---------- Field ---------- */
  var fid = 0;
  function Field(p) {
    var idRef = useRef(p.id || ('md-field-' + (++fid)));
    var id = idRef.current, tag = p.multiline ? 'textarea' : 'input';
    var input = {
      id: id, className: 'md-field-input', value: p.value, defaultValue: p.defaultValue, placeholder: p.placeholder,
      onChange: p.onChange, rows: p.multiline ? (p.rows || 3) : undefined, 'aria-invalid': p.error ? 'true' : undefined,
      'aria-describedby': (p.hint || p.error) ? id + '-hint' : undefined, readOnly: p.readOnly
    };
    return h('div', { className: cx('md-field', p.error && 'md-field-error', p.className) },
      h('label', { className: 'md-field-label', htmlFor: id }, p.label),
      h('div', { className: 'md-field-box' }, h(tag, input), p.trailing || null),
      (p.error || p.hint) ? h('p', { className: 'md-field-hint', id: id + '-hint' }, p.error ? h(Icon, { name: 'alert', size: 16 }) : null, p.error || p.hint) : null);
  }

  /* ---------- RecipeCard: the index-card motif ---------- */
  function RecipeCard(p) {
    var meta = [p.from && ('From ' + p.from), p.year, p.place].filter(Boolean).join(' · ');
    return h('article', { className: cx('md-rc', p.className) },
      h('div', { className: 'md-rc-card', 'aria-hidden': 'true' }, h('i', { className: 'md-rc-margin' }), p.quote ? h('span', { className: 'md-rc-hand' }, p.quote) : null),
      h('div', { className: 'md-rc-body' },
        p.chips && p.chips.length ? h('div', { className: 'md-rc-chips' }, p.chips.map(function (c, i) { return h(Chip, { key: i, tone: c.tone }, c.label); })) : null,
        h('h3', { className: 'md-rc-title' }, p.title),
        meta ? h('p', { className: 'md-rc-meta' }, meta) : null,
        h('dl', { className: 'md-rc-facts' },
          p.time ? h('div', null, h('dt', null, h(Icon, { name: 'clock', size: 18 }), 'Time'), h('dd', null, p.time)) : null,
          p.steps ? h('div', null, h('dt', null, h(Icon, { name: 'pot', size: 18 }), 'Steps'), h('dd', null, p.steps)) : null,
          p.serves ? h('div', null, h('dt', null, h(Icon, { name: 'heart', size: 18 }), 'Serves'), h('dd', null, p.serves)) : null)));
  }

  /* ---------- BoardStep: one instruction on the board surface ---------- */
  function mmss(s) { s = Math.max(0, Math.round(s)); var m = Math.floor(s / 60), x = s % 60; return (m < 10 ? '0' : '') + m + ':' + (x < 10 ? '0' : '') + x; }
  function BoardStep(p) {
    var hasTimer = p.timerTotal != null;
    var frac = hasTimer ? Math.max(0, Math.min(1, (p.timerLeft == null ? p.timerTotal : p.timerLeft) / p.timerTotal)) : 0;
    return h('section', { className: cx('md-bs', p.className), 'aria-label': 'Step ' + p.step + ' of ' + p.total },
      h('div', { className: 'md-bs-main' },
        h('p', { className: 'md-bs-eyebrow' }, 'Step ' + p.step + ' of ' + p.total, p.zone ? h('span', null, ' · ' + p.zone) : null),
        h('h2', { className: 'md-bs-title' }, p.instruction),
        p.cue ? h('p', { className: 'md-bs-cue' }, p.cue) : null,
        p.quote ? h('blockquote', { className: 'md-bs-quote' }, h('p', null, '“' + p.quote + '”'), p.quoteBy ? h('cite', null, p.quoteBy) : null) : null),
      hasTimer ? h('div', { className: cx('md-bs-timer', p.running && 'md-bs-running') },
        h('svg', { viewBox: '0 0 120 120', 'aria-hidden': 'true' },
          h('circle', { className: 'md-bs-track', cx: 60, cy: 60, r: 52, pathLength: 100 }),
          h('circle', { className: 'md-bs-arc', cx: 60, cy: 60, r: 52, pathLength: 100, strokeDasharray: (frac * 100) + ' 100', transform: 'rotate(-90 60 60)' })),
        h('span', { className: 'md-bs-time', role: 'timer' }, mmss(p.timerLeft == null ? p.timerTotal : p.timerLeft)),
        h('span', { className: 'md-bs-tlabel' }, p.running ? 'Running' : 'Paused')) : null);
  }


  /* ---------- ThermalWave: a heat wave of stepped thermal pixels that reveals (or hides) its container ---------- */
  var THERMAL_TOKENS = ['--thermal-violet', '--thermal-magenta', '--thermal-ember', '--thermal-flare'];
  function rgbOf(s) {
    s = (s || '').trim();
    if (s.charAt(0) === '#') { if (s.length === 4) s = '#' + s[1] + s[1] + s[2] + s[2] + s[3] + s[3]; return [parseInt(s.slice(1, 3), 16), parseInt(s.slice(3, 5), 16), parseInt(s.slice(5, 7), 16)]; }
    var m = s.match(/\d+(\.\d+)?/g); return m ? [+m[0], +m[1], +m[2]] : [128, 128, 128];
  }
  function ThermalWave(p) {
    var ref = useRef(null), mode = p.mode || 'in', CELL = p.cell || 10, MS = p.duration || 560;
    useEffect(function () {
      var c = ref.current; if (!c || reduced()) { if (p.onDone) p.onDone(); return; }
      var ctx = c.getContext('2d'), raf, dpr = window.devicePixelRatio || 1;
      var cs = getComputedStyle(c), pal = THERMAL_TOKENS.map(function (n) { return rgbOf(cs.getPropertyValue(n)); });
      var W = c.clientWidth, H = c.clientHeight, C = Math.ceil(W / CELL), Rr = Math.ceil(H / CELL);
      c.width = Math.round(W * dpr); c.height = Math.round(H * dpr); ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      var ox = p.originX == null ? 0 : p.originX, oy = p.originY == null ? 0 : p.originY;
      var s1 = Math.random() * 6, s2 = Math.random() * 6, s3 = Math.random() * 6, cells = [];
      for (var y = 0; y < Rr; y++) for (var x = 0; x < C; x++) {
        var u = x / C, v = y / Rr, dx = u - ox, dy = v - oy;
        var n = (Math.sin(u * 7.1 + s1) * Math.cos(v * 5.3 + s2) + Math.sin((u + v) * 11.7 + s3) * 0.6 + (Math.random() - 0.5) * 0.5) / 2.1;
        cells.push({ x: x * CELL, y: y * CELL, d: Math.sqrt(dx * dx * 0.55 + dy * dy) / 1.05 + n * 0.14, n: n });
      }
      var out = mode === 'out', t0 = performance.now();
      function frame(now) {
        var t = Math.min(1, (now - t0) / MS), r = t * 1.45 - 0.15, fade = out ? 1 - Math.max(0, (t - 0.8) / 0.2) : 1;
        ctx.clearRect(0, 0, W, H);
        for (var i = 0; i < cells.length; i++) {
          var q = cells[i], age = r - q.d, temp, alpha;
          if (age < 0) { var near = Math.max(0, 1 + age * 7); temp = 0.1 + q.n * 0.08 + near * near * 0.85; alpha = out ? near : 1; }
          else { temp = Math.max(0.04, 0.97 - age * 4.2) + q.n * 0.06; alpha = out ? 1 : Math.max(0, 1 - Math.max(0, age - 0.14) * 4.2); if (out) temp = Math.max(0.12 + q.n * 0.08, temp); }
          alpha *= fade; if (alpha <= 0.01) continue;
          var k = pal[Math.max(0, Math.min(3, Math.floor(temp * 4)))];
          ctx.fillStyle = 'rgba(' + k[0] + ',' + k[1] + ',' + k[2] + ',' + alpha.toFixed(3) + ')';
          ctx.fillRect(q.x, q.y, CELL - 1, CELL - 1);
        }
        if (t < 1) raf = requestAnimationFrame(frame); else { if (!out) ctx.clearRect(0, 0, W, H); if (p.onDone) p.onDone(); }
      }
      raf = requestAnimationFrame(frame);
      return function () { cancelAnimationFrame(raf); };
    }, []);
    return h('canvas', { ref: ref, className: cx('md-thermal', p.className), 'aria-hidden': 'true' });
  }

  var api = { Button: Button, Chip: Chip, Icon: Icon, ProgressPill: ProgressPill, StepTimeline: StepTimeline, Quantity: Quantity, ServingStepper: ServingStepper, Field: Field, RecipeCard: RecipeCard, BoardStep: BoardStep, ThermalWave: ThermalWave };
  window.Moldable = window.Moldable || {};
  Object.assign(window.Moldable, api);
})();
