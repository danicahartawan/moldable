# RecipeCard

A saved recipe, drawn as a vintage index card: blue ruling, a red header line, and a line of the cook's own handwriting, set in the display face, above the title and facts.

**Props:** `title` · `from` (the cook) · `year` · `place` · `quote` (a short line of her words, shown as handwriting) · `time` · `steps` · `serves` · `chips` `[{ tone, label }]`.

- Keep `quote` in the original language and spelling. Never translate or correct it here.
- Use a maximum of two chips: heritage status plus save state.
- The ruled header is decorative and hidden from screen readers. Don't put information only there.
- Cards sit on `flour` with `shadow-1`, at most 420px wide, in a grid with `space-5` gaps.
