# BoardStep

The single instruction the board shows while someone cooks: what to do, the sensory cue that tells them it's done, the original cook's words, and a timer if the step needs one.

**Props:** `step`, `total` · `instruction` (imperative, under 8 words) · `cue` (what you'll see, smell or hear) · `quote`, `quoteBy` (her words, verbatim, with the source) · `zone` (where on the board, e.g. "Left of board") · `timerTotal`, `timerLeft` (seconds) · `running`.

- Show one step at a time. The board never shows a list.
- Use the **Board (dark)** theme on the physical surface; the light theme is for phones and tablets.
- `instruction` uses `board-step` (44px) and `cue` uses `board-cue` (28px). Both are sized to be read from standing height. Don't go smaller on the board.
- The cue is the most important line for a beginner. Write it as something they can check: "until the oil separates", not "until done".
- Only the running timer glows. A paused timer uses `line-strong`.
