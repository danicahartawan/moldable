# ProgressPill

Shows a long task such as uploading or transcribing: a glowing `yolk` stroke travels round the pill's outline while the label says what is happening.

**Props:** `label` (required; also the accessible name) · `value` 0–1, or leave it out for indeterminate · `icon` · `showValue` (default true).

- Use it for anything over about 1.5s that the person waits on. Shorter actions use `Button`'s `working` status.
- The label names the recipe or person: "Uploading Oma's card", not "Uploading file".
- Indeterminate: a short stroke circles the outline. Switch to a value once the real progress is known.
- The glow is reserved for this pill and the running timer. Nothing else on screen should glow at the same time.
- Give it 10px of clear space on every side; the stroke draws outside the pill.
