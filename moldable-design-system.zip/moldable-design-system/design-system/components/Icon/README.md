# Icon

Moldable's line icons, drawn on a 20px grid with a 1.6 stroke, round caps and joins, in `currentColor`.

**Props:** `name` (one of `Icon.names`) · `size` px (default 20) · `strokeWidth` · `label` (set it only when the icon stands alone and means something; otherwise it is hidden from screen readers).

- The icon takes the colour of its text. Never colour an icon differently from the label beside it.
- 20px in controls, 18px in chips and fact rows, 24px or larger on the board.
- Kitchen glyphs (`knife`, `pot`, `flame`) are for cooking actions only, not decoration.
