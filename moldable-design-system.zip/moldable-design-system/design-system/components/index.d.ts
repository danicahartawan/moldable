/** Moldable components. Global: window.Moldable. Requires React 18. */
export type IconName = 'check' | 'check-circle' | 'x' | 'x-circle' | 'pencil' | 'clock' | 'flame' | 'alert' | 'scan' | 'book' | 'eye' | 'knife' | 'mic' | 'plus' | 'minus' | 'share' | 'heart' | 'pot';
export type Tone = 'neutral' | 'yolk' | 'basil' | 'enamel' | 'heirloom' | 'chili';

export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'quiet';
  size?: 'md' | 'lg';
  icon?: IconName;
  status?: 'idle' | 'working' | 'done';
  workingLabel?: React.ReactNode;
  doneLabel?: React.ReactNode;
}
export interface ChipProps { tone?: Tone; icon?: IconName | false; children: React.ReactNode; className?: string; }
export interface IconProps { name: IconName; size?: number; strokeWidth?: number; label?: string; className?: string; }
export interface ProgressPillProps { label: string; value?: number; icon?: IconName; showValue?: boolean; className?: string; }
export interface StepTimelineProps { steps: { label: string; note?: string }[]; active: number; progress?: number; label?: string; className?: string; }
export interface QuantityProps { value: number; unit?: string; className?: string; }
export interface ServingStepperProps { value: number; onChange: (n: number) => void; min?: number; max?: number; className?: string; }
export interface FieldProps {
  label: string; id?: string; value?: string; defaultValue?: string; placeholder?: string;
  onChange?: (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => void;
  hint?: React.ReactNode; error?: React.ReactNode; multiline?: boolean; rows?: number; readOnly?: boolean; trailing?: React.ReactNode; className?: string;
}
export interface RecipeCardProps {
  title: string; from?: string; year?: string; place?: string; quote?: string;
  time?: string; steps?: number; serves?: number; chips?: { tone: Tone; label: string }[]; className?: string;
}
export interface BoardStepProps {
  step: number; total: number; instruction: string; cue?: string; quote?: string; quoteBy?: string; zone?: string;
  timerTotal?: number; timerLeft?: number; running?: boolean; className?: string;
}
export interface ThermalWaveProps {
  /** 'in' burns away to reveal what's under it; 'out' covers it again. Remount (change key) to replay. */
  mode?: 'in' | 'out'; cell?: number; duration?: number; originX?: number; originY?: number; onDone?: () => void; className?: string;
}
export declare const Button: React.FC<ButtonProps>;
export declare const Chip: React.FC<ChipProps>;
export declare const Icon: React.FC<IconProps> & { names: IconName[] };
export declare const ProgressPill: React.FC<ProgressPillProps>;
export declare const StepTimeline: React.FC<StepTimelineProps>;
export declare const Quantity: React.FC<QuantityProps>;
export declare const ServingStepper: React.FC<ServingStepperProps>;
export declare const Field: React.FC<FieldProps>;
export declare const RecipeCard: React.FC<RecipeCardProps>;
export declare const BoardStep: React.FC<BoardStepProps>;
export declare const ThermalWave: React.FC<ThermalWaveProps>;
