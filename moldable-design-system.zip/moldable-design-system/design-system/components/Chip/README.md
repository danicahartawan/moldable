# Chip

A pastel pill with a matching darker icon and label that names a recipe's state at a glance.

**Props:** `tone` `"neutral" | "yolk" | "basil" | "enamel" | "heirloom" | "chili"` · `icon` an `Icon` name, or `false` for none (each tone has a default) · `children` the label.

| Tone | Means | Default icon |
| --- | --- | --- |
| neutral | Draft, not yet saved | pencil |
| yolk | In progress or needs a person: Transcribing, Needs a look | alert |
| basil | Saved, Done | check-circle |
| enamel | Shared with family | share |
| heirloom | Marked as a family heirloom | book |
| chili | Failed: Couldn't read, Upload failed | x-circle |

- Always keep the icon: tone alone must never carry the meaning.
- Labels are one to three words, sentence case.
- Chips are not buttons. If tapping does something, use a `Button` with `variant="quiet"`.
